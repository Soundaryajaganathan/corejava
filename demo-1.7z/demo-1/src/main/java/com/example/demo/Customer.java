package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;

public class Customer {

	private String custName;
	
	@Autowired
	private Company company;
	
	public Customer(String custName, Company company) {
		this.custName=custName;
		this.company=company;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}
	
}