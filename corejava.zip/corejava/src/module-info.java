module corej {
}