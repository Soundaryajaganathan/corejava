package corejava;

import java.util.Random;
import java.util.Scanner;

public class advice {


	public static void main(String args[])
	{
		int count=0;
		do
		{
		
		String advice[]= {"advice 1","advice2","advice 3","advice 4"};
		Scanner sc=new Scanner(System.in);
		Random r=new Random();
		int line=r.nextInt(advice.length);
		System.out.println("Ask me a question: ");
		String q=sc.nextLine();
		System.out.println("Advide: "+advice[line]);
		count++;
		}while(count!=4);
		
	}
}
