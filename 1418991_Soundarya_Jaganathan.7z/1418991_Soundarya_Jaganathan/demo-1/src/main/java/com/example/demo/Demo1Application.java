package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Demo1Application {
	
	@Bean
	public String getName() {
		return "ABC";
	}

	public static void main(String[] args) {
		
		/*ApplicationContext context = SpringApplication.run(Demo1Application.class, args);
		
		for(String string : context.getBeanDefinitionNames()) {
			//System.out.println(string);
		}
		
		Customer cu=context.getBean("customer",Customer.class);
		System.out.println(cu.getCustName());

		//using @component
		Company c= context.getBean("company", Company.class);
		System.out.println(c.getName());
		//System.out.println(c.getLocation());*/
		
	ConfigurableApplicationContext context = SpringApplication.run(Demo1Application.class, args);
    
    ServiceAspect service = context.getBean(ServiceAspect.class);
    
    String employeeNumber = "emp12345";
    try {
        service.employeeStatus(employeeNumber);
    }
    catch (Exception ex) {
        System.out.println("Exception occurred.."+ ex.getMessage());
    }
    String employeeAccountNumber = "Emp1212";
    try {
        service.getAccountBalance(
            employeeAccountNumber);
    }
    catch (Exception ex) {
        System.out.println("Exception occurred.."+ ex.getMessage());
    }
    int promotionExamMarks = 650;
    try {
        service.eligibilityForPromotion(
            promotionExamMarks);
    }
    catch (Exception ex) {
        System.out.println("Exception occurred.."+ ex.getMessage());
    }
    context.close();

	}

}
